package loggers

import (
	"fmt"
	"log"
	"os"
)

var (
	ErrorData *log.Logger
	WarnData  *log.Logger
	InfoData  *log.Logger
)

func init() {
	// LOG_FILE := "pkg/loggers/log.txt"
	// logs_file := os.Path.join(LOG_FILE, "logs.txt")
	file, err := os.OpenFile("logs.txt", os.O_CREATE|os.O_APPEND|os.O_WRONLY|os.O_RDONLY, 0777)
	if err != nil {
		fmt.Println("Error Occured", err)
		return
	}
	InfoData = log.New(file, "INFO: ", log.Lshortfile|log.LstdFlags)
	ErrorData = log.New(file, "ERROR: ", log.Lshortfile|log.LstdFlags)
	WarnData = log.New(file, "WARN:", log.Lshortfile|log.LstdFlags)
}

// # Step 1: Ensure the directory exists
// log_dir = 'pkg/loggers'
// os.makedirs(log_dir, exist_ok=True)

// # Step 2: Define the log file path
// log_file = os.path.join(log_dir, 'logs.txt')
