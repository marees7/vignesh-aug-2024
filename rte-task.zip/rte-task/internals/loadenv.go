package internals

import (
	"fmt"

	"github.com/Vigneshwartt/golang-rte-task/pkg/loggers"
	"github.com/joho/godotenv"
)

func recoverPanic() {
	if r := recover(); r != nil {
		fmt.Println("recovered from ", r)
	}
}

func LoadEnv() {
	defer recoverPanic()

	err := godotenv.Load("C:/Projects/Golang-exercise/github/vignesh-aug-2024/rte-task/internals/config/.env")
	if err != nil {
		loggers.ErrorData.Fatalf("Error loading .env file: %v", err)
	}
}
