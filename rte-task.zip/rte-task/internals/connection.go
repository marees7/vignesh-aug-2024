package internals

import (
	"fmt"
	"os"

	"github.com/Vigneshwartt/golang-rte-task/loadconfig"
	"github.com/Vigneshwartt/golang-rte-task/pkg/loggers"

	// "github.com/joho/godotenv"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

type ConnectionNew struct {
	*gorm.DB
}

func ConnectingDatabase() *ConnectionNew {
	fmt.Println("checking")
	err := loadconfig.Loadconfig(".env")
	if err != nil {
		loggers.ErrorData.Println("Error failed to load the env file ")
		return nil
	}

	host := os.Getenv("HOST")
	user := os.Getenv("USER")
	port := os.Getenv("PORT")
	password := os.Getenv("PASSWORD")
	dbname := os.Getenv("DB")

	path := fmt.Sprintf("host=%s user=%s port=%s password=%s dbname=%s", host, user, port, password, dbname)
	Connection, err := gorm.Open(postgres.Open(path), &gorm.Config{})
	if err != nil {
		panic(err)
	}
	defer HandlePanic()
	loggers.InfoData.Println("Connected sucessfully")
	return &ConnectionNew{
		Connection,
	}
}

func HandlePanic() {
	if err := recover(); err != nil {
		loggers.ErrorData.Println("Recover:", err)
	}
}
