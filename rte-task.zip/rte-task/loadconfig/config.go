package loadconfig

import (
	"github.com/Vigneshwartt/golang-rte-task/pkg/loggers"
	"github.com/joho/godotenv"
)

func Loadconfig(filename string) error {
	err := godotenv.Load(filename)
	if err != nil {
		loggers.ErrorData.Println("Error failed to load the env file ")
		return nil
	}
	return nil
}
