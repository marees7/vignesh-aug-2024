package repository

import (
	"github.com/Vigneshwartt/golang-rte-task/internals"
	"github.com/Vigneshwartt/golang-rte-task/pkg/models"
)

type I_AuthRepo interface {
	GetValidEmailAddress(user *models.UserDetails, count int64) (int64, error)
	CreateUsers(user *models.UserDetails) error
	GetUserMails(user *models.UserDetails, founduser *models.UserDetails) error
	GetPhoneNumber(user *models.UserDetails, count int64) (int64, error)
}

type AuthRepo struct {
	*internals.ConnectionNew
}

func GetAuthRepository(db *internals.ConnectionNew) I_AuthRepo {
	return &AuthRepo{
		db,
	}
}

// check email is exixts or not in DB
func (database *AuthRepo) GetValidEmailAddress(user *models.UserDetails, count int64) (int64, error) {
	DbEmail := database.Model(&models.UserDetails{}).Where("email=?", user.Email).Count(&count)
	if DbEmail.Error != nil {
		return 0, DbEmail.Error
	}

	return count, nil
}

// create user details By their roles
func (database *AuthRepo) CreateUsers(user *models.UserDetails) error {
	dbvalues := database.Create(user)
	if dbvalues.Error != nil {
		return dbvalues.Error
	}

	return nil
}

// Check Email address while Login with their email ID
func (database *AuthRepo) GetUserMails(user *models.UserDetails, founduser *models.UserDetails) error {
	value := database.Where("email=?", user.Email).First(&founduser)
	if value.Error != nil {
		return value.Error
	}

	return nil
}

// check phone number is exists or not in DB
func (database *AuthRepo) GetPhoneNumber(user *models.UserDetails, count int64) (int64, error) {
	DbPhone := database.Model(&models.UserDetails{}).Where("phone_number=?", user.PhoneNumber).Count(&count)
	if DbPhone.Error != nil {
		return 0, DbPhone.Error
	}

	return count, nil
}
