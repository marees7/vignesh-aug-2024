package service

import (
	"github.com/Vigneshwartt/golang-rte-task/api/repository"
	"github.com/Vigneshwartt/golang-rte-task/pkg/models"
)

type I_AuthService interface {
	GetValidEmail(user *models.UserDetails, count int64) (int64, error)
	CreateUser(user *models.UserDetails) error
	GetUserMail(user *models.UserDetails, founduser *models.UserDetails) error
	GetValidUserNumber(user *models.UserDetails, count int64) (int64, error)
}

type AuthService struct {
	repository.I_AuthRepo
}

func GetAuthService(db repository.I_AuthRepo) I_AuthService {
	return &AuthService{
		db,
	}
}

// check email is exixts or not in DB
func (repo *AuthService) GetValidEmail(user *models.UserDetails, count int64) (int64, error) {
	return repo.GetValidEmailAddress(user, count)
}

// check phone number is exists or not in DB
func (repo *AuthService) GetValidUserNumber(user *models.UserDetails, count int64) (int64, error) {
	return repo.GetPhoneNumber(user, count)
}

// create user details By their roles
func (repo *AuthService) CreateUser(user *models.UserDetails) error {
	return repo.CreateUsers(user)
}

// Check Email address while Login with their email ID
func (repo *AuthService) GetUserMail(user *models.UserDetails, founduser *models.UserDetails) error {
	return repo.GetUserMails(user, founduser)
}
